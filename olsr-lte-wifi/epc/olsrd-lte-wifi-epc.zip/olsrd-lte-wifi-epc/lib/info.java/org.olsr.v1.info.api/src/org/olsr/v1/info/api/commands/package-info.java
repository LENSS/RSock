@org.osgi.annotation.versioning.Version("1.0.0")
package org.olsr.v1.info.api.commands;