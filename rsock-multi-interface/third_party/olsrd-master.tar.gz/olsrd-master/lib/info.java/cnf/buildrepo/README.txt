WARNING
=======

This directory contains JAR file dependencies that are intended ONLY FOR BUILT-TIME usage.
None are intended to be deployed as bundles into a running OSGi Framework, and indeed they may cause
unexpected errors if they are used at runtime.
